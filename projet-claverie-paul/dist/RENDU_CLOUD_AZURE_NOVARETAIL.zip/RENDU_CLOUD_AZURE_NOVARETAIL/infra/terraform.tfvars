# =====================================================================
# terraform.tfvars — Valeurs de déploiement pour NovaRetail
#
# IMPORTANT (sécurité) : ce fichier NE contient AUCUN secret.
# Les mots de passe (VM, MySQL) sont générés par Terraform (tls/random)
# et ne sont jamais versionnés. Ce fichier est néanmoins listé dans
# .gitignore par précaution (cf. correction de l'anomalie 9, Partie 2).
# =====================================================================

project_name = "novaretail"
location     = "swedencentral"
environment  = "prod"
prefix       = "nr"

vnet_address_space = ["10.10.0.0/16"]
web_subnet_prefix  = ["10.10.1.0/24"]
data_subnet_prefix = ["10.10.2.0/24"]

vm_size        = "Standard_D2s_v3"
vm_count       = 2
admin_username = "azureadmin"

# SSH restreint : par défaut, accès limité au réseau virtuel (VirtualNetwork).
# Pour de l'administration directe, renseigner ici votre IP publique en /32,
# par exemple : admin_source_address = "203.0.113.10/32"
admin_source_address = "VirtualNetwork"

# Base de données managée (passer à false pour un déploiement plus rapide/économique)
deploy_mysql = true

tags = {
  application = "novaretail"
  owner       = "dsi.ops"
  cost-center = "cc-novaretail"
  criticality = "high"
  review-date = "2026-12-31"
}
